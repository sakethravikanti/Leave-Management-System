package com.lms.web.model;

public enum ExitRequestStatus {
    PENDING,
    ACCEPTED,
    CANCELLED
}