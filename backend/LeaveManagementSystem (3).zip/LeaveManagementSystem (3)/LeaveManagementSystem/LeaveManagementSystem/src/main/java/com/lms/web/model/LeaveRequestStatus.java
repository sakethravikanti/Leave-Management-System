package com.lms.web.model;

public enum LeaveRequestStatus {
	ACCEPTED,
	REJECTED,
	CANCELLED,
	PENDING
}
