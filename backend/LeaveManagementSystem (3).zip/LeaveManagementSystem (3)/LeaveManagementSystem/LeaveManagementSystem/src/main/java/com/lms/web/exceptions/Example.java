package com.lms.web.exceptions;

public class Example {

}
