package com.lms.web.model;

public enum AttendanceStatus {
	ABSENT,
	PRESENT,
	HALF_DAY
}